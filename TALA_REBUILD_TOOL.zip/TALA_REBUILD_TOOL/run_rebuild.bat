@echo off
REM Run from TalaRipper folder:
REM   run_rebuild.bat
python TALA_REBUILD_TOOL\rebuild.py --in exports\reconstructed --out exports\rebuilt
echo.
echo Done. Check exports\rebuilt\
pause
