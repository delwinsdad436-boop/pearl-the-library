TALA Rebuild Tool (Local, Windows)
=================================

Goal
----
Take the messy reconstructed TXT files in:
  exports\reconstructed\*.txt
and produce clean, readable outputs + TALA-ready chunks WITHOUT losing knowledge.

Your choices (baked into defaults)
----------------------------------
- Preserve knowledge over original formatting.
- Aggressive OCR-noise cleanup, but with safeguards (we keep backups + logs).
- Best-for-TALA: we produce BOTH:
    (a) merged clean “books” where we can
    (b) still keep clean shards for flexible recall
- Prioritize legal + dictionary outputs first.

Quick Start (Windows CMD)
-------------------------
1) Put this folder inside your TalaRipper folder.
   Example: C:\Users\<you>\TalaRipper\TALA_REBUILD_TOOL\

2) From inside TalaRipper, run:
   python TALA_REBUILD_TOOL\rebuild.py --in exports\reconstructed --out exports\rebuilt

3) After it finishes, check:
   exports\rebuilt\01_legal_dictionary\
   exports\rebuilt\02_other\
   exports\rebuilt\_MERGED\
   exports\rebuilt\_TALA_CHUNKS\
   exports\rebuilt\manifest.json
   exports\rebuilt\rebuild_log.jsonl

What you get
------------
- Clean TXT per source shard (and per detected category)
- Merged “books” when possible (still reversible)
- TALA chunks as JSONL blocks (default 200 per block)
- SHA256 manifest
- Logs of what was changed

Back out / Stop
---------------
- If it's running in CMD: press CTRL+C (safe stop).
- Nothing overwrites your originals.
  Inputs stay in exports\reconstructed\
  Outputs go to exports\rebuilt\
