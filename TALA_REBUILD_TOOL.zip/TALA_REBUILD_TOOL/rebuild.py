#!/usr/bin/env python3
import argparse, os, re, json, hashlib, datetime, pathlib, codecs
from collections import Counter

CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F]")
MULTI_SPACE_RE = re.compile(r"[ \t]{2,}")
BROKEN_WRAP_RE = re.compile(r"(?<!\n)\n(?!\n)")  # single newlines inside paragraphs
HYPHEN_BREAK_RE = re.compile(r"(\w)-\n(\w)")     # hyphen at line end
ESCAPED_N_RE = re.compile(r"\\n")
ESCAPED_T_RE = re.compile(r"\\t")
ESCAPED_R_RE = re.compile(r"\\r")

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def safe_unicode_unescape(s: str) -> str:
    # If the text includes many "\uXXXX" or "\n" escapes, decode them.
    # Safeguard: only apply if it seems necessary.
    if ("\\u" in s) or ("\\n" in s) or ("\\t" in s):
        try:
            return codecs.decode(s, "unicode_escape")
        except Exception:
            return s
    return s

def normalize_text(raw: str, aggressive: bool):
    before = raw
    changes = []

    # 1) Decode unicode escapes if present
    decoded = safe_unicode_unescape(before)
    if decoded != before:
        changes.append("unicode_escape_decode")
    s = decoded

    # 2) Normalize newlines
    s2 = s.replace("\r\n", "\n").replace("\r", "\n")
    if s2 != s:
        changes.append("newline_normalize")
    s = s2

    # 3) Remove control chars
    s2 = CONTROL_CHARS_RE.sub("", s)
    if s2 != s:
        changes.append("remove_control_chars")
    s = s2

    # 4) De-junk common JSON-ish debris (light touch)
    # Keep safeguards: don't delete whole lines unless obviously metadata.
    junk_patterns = [
        r'^\s*{"_?exported_at":.*$',
        r'^\s*"(_?sha256|_?src|_?words|_?cells|_?meta)":.*$',
        r'^\s*\[?\s*{?\s*"_?sha256":.*$',
    ]
    cleaned_lines = []
    removed = 0
    for line in s.split("\n"):
        if any(re.match(p, line) for p in junk_patterns):
            removed += 1
            continue
        cleaned_lines.append(line)
    if removed:
        changes.append(f"remove_json_meta_lines:{removed}")
    s = "\n".join(cleaned_lines)

    # 5) Fix hyphenated line breaks
    s2 = HYPHEN_BREAK_RE.sub(r"\1\2", s)
    if s2 != s:
        changes.append("fix_hyphen_breaks")
    s = s2

    # 6) Collapse excessive spaces
    s2 = MULTI_SPACE_RE.sub(" ", s)
    if s2 != s:
        changes.append("collapse_spaces")
    s = s2

    # 7) Paragraph rebuild: convert single newlines into spaces
    # Keep double-newlines as paragraph breaks.
    if aggressive:
        parts = s.split("\n\n")
        new_parts = []
        for p in parts:
            p = p.strip()
            if not p:
                continue
            p2 = BROKEN_WRAP_RE.sub(" ", p)
            # Clean doubled spaces after wrap
            p2 = MULTI_SPACE_RE.sub(" ", p2)
            new_parts.append(p2)
        s2 = "\n\n".join(new_parts) + "\n"
        changes.append("reflow_paragraphs_aggressive")
        s = s2
    else:
        # light: still collapse single-newline runs a bit
        s = s.strip() + "\n"
        changes.append("trim_only_safe")

    # 8) Final: trim repeated blank lines
    s2 = re.sub(r"\n{3,}", "\n\n", s)
    if s2 != s:
        changes.append("collapse_blank_lines")
    s = s2

    return s, changes

def classify(text: str, filename: str, cfg: dict) -> str:
    low = (filename + " " + text[:5000]).lower()
    rules = cfg.get("category_rules", {})
    scores = Counter()

    for cat, r in rules.items():
        for kw in r.get("keywords", []):
            if kw in low:
                scores[cat] += 3
        for sig in r.get("signals", []):
            if sig in low:
                scores[cat] += 1

    # Heuristic: if it looks dictionary-like (lots of "noun", "adj", "plural")
    dict_hits = len(re.findall(r"\b(noun|adj|adjective|verb|plural)\b", low))
    if dict_hits >= 10:
        scores["legal_dictionary"] += 2

    if scores:
        cat = scores.most_common(1)[0][0]
        # Normalize categories
        if cat == "cookbooks":
            return "02_other/cookbooks"
        if cat == "legal_dictionary":
            return "01_legal_dictionary"
    return "02_other/misc"

def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def write_log(log_path: str, entry: dict):
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

def chunk_to_jsonl(clean_text: str, source_name: str, chunk_size: int):
    # Split into paragraphs, then pack paragraphs into blocks.
    paras = [p.strip() for p in clean_text.split("\n\n") if p.strip()]
    blocks = []
    cur = []
    count = 0
    for p in paras:
        cur.append(p)
        count += 1
        if count >= chunk_size:
            blocks.append(cur)
            cur = []
            count = 0
    if cur:
        blocks.append(cur)

    # Each block becomes a record with list of paragraphs.
    jsonl_records = []
    for i, b in enumerate(blocks):
        jsonl_records.append({
            "source": source_name,
            "block_index": i,
            "paragraphs": b
        })
    return jsonl_records

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="Input folder containing reconstructed .txt files")
    ap.add_argument("--out", dest="out", required=True, help="Output folder")
    ap.add_argument("--config", default=None, help="config.json path (optional)")
    ap.add_argument("--safe", action="store_true", help="Safer cleanup (less reflow)")
    args = ap.parse_args()

    cfg = {}
    if args.config and os.path.exists(args.config):
        cfg = json.loads(open(args.config, "r", encoding="utf-8").read())
    else:
        # try local config next to script
        here = os.path.dirname(os.path.abspath(__file__))
        cfg_path = os.path.join(here, "config.json")
        if os.path.exists(cfg_path):
            cfg = json.loads(open(cfg_path, "r", encoding="utf-8").read())

    aggressive = not args.safe
    out_root = args.out
    ensure_dir(out_root)

    log_path = os.path.join(out_root, "rebuild_log.jsonl")
    manifest_path = os.path.join(out_root, "manifest.json")
    chunks_root = os.path.join(out_root, "_TALA_CHUNKS")
    merged_root = os.path.join(out_root, "_MERGED")
    ensure_dir(chunks_root)
    ensure_dir(merged_root)

    inp = args.inp
    files = sorted([f for f in os.listdir(inp) if f.lower().endswith(".txt")])
    if not files:
        print(f"[rebuild] No .txt files found in: {inp}")
        return

    manifest = {
        "created_at": datetime.datetime.utcnow().isoformat() + "Z",
        "input_dir": os.path.abspath(inp),
        "output_dir": os.path.abspath(out_root),
        "mode": "aggressive_with_safeguards" if aggressive else "safe",
        "files": []
    }

    # (A) clean per file + categorize
    merged_buckets = {}  # bucket -> list of text
    total_in = 0
    total_out = 0
    for fn in files:
        in_path = os.path.join(inp, fn)
        raw = open(in_path, "r", encoding="utf-8", errors="replace").read()
        total_in += len(raw)

        clean, changes = normalize_text(raw, aggressive=aggressive)

        cat = classify(clean, fn, cfg)
        out_dir = os.path.join(out_root, cat)
        ensure_dir(out_dir)

        # keep backups if requested
        if cfg.get("keep_backups", True):
            bdir = os.path.join(out_root, "_BACKUPS")
            ensure_dir(bdir)
            with open(os.path.join(bdir, fn), "w", encoding="utf-8") as f:
                f.write(raw)

        out_path = os.path.join(out_dir, fn.replace(".txt", "__CLEAN.txt"))
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(clean)
        total_out += len(clean)

        entry = {
            "file": fn,
            "category": cat,
            "input_sha256": sha256_file(in_path),
            "output_sha256": sha256_file(out_path),
            "changes": changes,
            "input_bytes": os.path.getsize(in_path),
            "output_bytes": os.path.getsize(out_path),
        }
        manifest["files"].append(entry)
        write_log(log_path, {"ts": datetime.datetime.utcnow().isoformat()+"Z", **entry})

        # create chunks jsonl per clean file
        chunk_size = int(cfg.get("chunk_size", 200))
        records = chunk_to_jsonl(clean, source_name=fn, chunk_size=chunk_size)
        chunk_out = os.path.join(chunks_root, fn.replace(".txt", "") + ".jsonl")
        with open(chunk_out, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

        # add to merge bucket by category
        bucket = cat.split("/")[0] if "/" in cat else cat
        merged_buckets.setdefault(bucket, []).append(clean)

        print(f"[rebuild] {fn} -> {cat} | chunks={len(records)}")

    # (B) merged outputs
    for bucket, texts in merged_buckets.items():
        merged_text = "\n\n".join(t.strip() for t in texts if t.strip()) + "\n"
        merged_path = os.path.join(merged_root, f"{bucket}__MERGED.txt")
        with open(merged_path, "w", encoding="utf-8") as f:
            f.write(merged_text)

    # (C) write manifest
    manifest["stats"] = {
        "input_files": len(files),
        "total_input_chars": total_in,
        "total_output_chars": total_out
    }
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print(f"[rebuild] DONE. Output: {out_root}")
    print(f"[rebuild] manifest: {manifest_path}")
    print(f"[rebuild] tala chunks: {chunks_root}")

if __name__ == "__main__":
    main()
