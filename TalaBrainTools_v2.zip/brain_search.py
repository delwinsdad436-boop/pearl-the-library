#!/usr/bin/env python3
"""
brain_search.py — fast offline search over brain_index.sqlite

Usage:
  python brain_search.py plants
  python brain_search.py "due process" --limit 8
  python brain_search.py --probe
"""
import argparse, sys, sqlite3
from brain_common import connect, detect_brain_table, get_columns, format_hit, normalize_text

def build_where(cols):
    # Try common text fields first
    candidates = [c for c in cols if c.lower() in ("text","definition","content","body","title","term","headword","name")]
    if not candidates:
        # fallback: any column that looks like text
        candidates = [c for c in cols if c.lower() not in ("id","rowid","idx","ts","hash","sha256")]
    # Use LIKE across candidate columns
    parts = [f"{c} LIKE ?" for c in candidates]
    return " OR ".join(parts), candidates

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query", nargs="?", help="text to search for")
    ap.add_argument("--db", default="brain_index.sqlite")
    ap.add_argument("--limit", type=int, default=10)
    ap.add_argument("--probe", action="store_true", help="show DB tables/columns and exit")
    args = ap.parse_args()

    conn = connect(args.db)
    table = detect_brain_table(conn)
    cols = get_columns(conn, table)

    if args.probe:
        print("DB:", args.db)
        print("Table:", table)
        print("Columns:", ", ".join(cols))
        return 0

    if not args.query:
        print('Usage: python brain_search.py "query" [--limit N]  (or --probe)')
        return 2

    where_sql, used_cols = build_where(cols)
    q = f"%{args.query}%"
    params = [q] * len(used_cols)
    # Prefer deterministic ordering if id-like column exists
    order = "rowid"
    if "id" in [c.lower() for c in cols]:
        order = "id"
    sql = f"SELECT rowid as rowid, * FROM {table} WHERE ({where_sql}) LIMIT ?"
    rows = conn.execute(sql, (*params, args.limit)).fetchall()

    if not rows:
        print("No matches found in your brain yet.")
        return 0

    print(f"Matches: {len(rows)} (table={table})")
    for i, r in enumerate(rows, 1):
        d = dict(r)
        hit = format_hit(d, cols)
        snippet = hit["text"][:300].replace("\n"," ")
        print(f"\n#{i} {hit['title']}")
        if hit["source"]:
            print(f"Source: {hit['source']}")
        print(snippet + ("..." if len(hit["text"]) > 300 else ""))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
