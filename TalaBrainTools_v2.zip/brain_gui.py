#!/usr/bin/env python3
"""
brain_gui.py — minimal GUI search for Tala brain (Tkinter, stdlib)

Run:
  python brain_gui.py
"""
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from brain_common import connect, detect_brain_table, get_columns, format_hit

DB_PATH = "brain_index.sqlite"

def retrieve(conn, table, cols, query, limit=20):
    text_cols = [c for c in cols if c.lower() in ("text","definition","content","body","title","term","headword","name")]
    if not text_cols:
        text_cols = [c for c in cols if c.lower() not in ("id","rowid","idx","ts","hash","sha256")]
    where = " OR ".join([f"{c} LIKE ?" for c in text_cols])
    q = f"%{query}%"
    params = [q]*len(text_cols)
    rows = conn.execute(f"SELECT rowid as rowid, * FROM {table} WHERE ({where}) LIMIT ?", (*params, limit)).fetchall()
    hits = []
    for r in rows:
        hits.append(format_hit(dict(r), cols))
    return hits

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TALA Brain GUI (offline)")
        self.geometry("1000x650")
        self.conn = connect(DB_PATH)
        self.table = detect_brain_table(self.conn)
        self.cols = get_columns(self.conn, self.table)
        self.hits = []

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)

        ttk.Label(top, text="Query:").pack(side="left")
        self.q = ttk.Entry(top, width=60)
        self.q.pack(side="left", padx=8)
        self.q.bind("<Return>", lambda e: self.do_search())

        ttk.Button(top, text="Search", command=self.do_search).pack(side="left")
        ttk.Button(top, text="Probe", command=self.probe).pack(side="left", padx=8)

        mid = ttk.Panedwindow(self, orient="horizontal")
        mid.pack(fill="both", expand=True, padx=10, pady=10)

        left = ttk.Frame(mid)
        right = ttk.Frame(mid)
        mid.add(left, weight=1)
        mid.add(right, weight=3)

        self.listbox = tk.Listbox(left, height=30)
        self.listbox.pack(fill="both", expand=True)
        self.listbox.bind("<<ListboxSelect>>", lambda e: self.show_selected())

        self.text = scrolledtext.ScrolledText(right, wrap="word")
        self.text.pack(fill="both", expand=True)

        status = ttk.Label(self, text=f"DB={DB_PATH} | table={self.table}", anchor="w")
        status.pack(fill="x", padx=10, pady=(0,10))

    def probe(self):
        messagebox.showinfo("Probe", f"DB: {DB_PATH}\nTable: {self.table}\nColumns:\n" + ", ".join(self.cols))

    def do_search(self):
        query = self.q.get().strip()
        self.listbox.delete(0, tk.END)
        self.text.delete("1.0", tk.END)
        if not query:
            return
        self.hits = retrieve(self.conn, self.table, self.cols, query, limit=50)
        if not self.hits:
            self.text.insert(tk.END, "No matches found.")
            return
        for i, h in enumerate(self.hits, 1):
            title = h["title"]
            src = f" [{h['source']}]" if h["source"] else ""
            self.listbox.insert(tk.END, f"{i}. {title}{src}")
        self.listbox.selection_set(0)
        self.show_selected()

    def show_selected(self):
        if not self.hits:
            return
        sel = self.listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        h = self.hits[idx]
        self.text.delete("1.0", tk.END)
        self.text.insert(tk.END, h["title"] + "\n")
        if h["source"]:
            self.text.insert(tk.END, f"Source: {h['source']}\n\n")
        self.text.insert(tk.END, h["text"])

    def on_close(self):
        try:
            self.conn.close()
        except Exception:
            pass
        self.destroy()

if __name__ == "__main__":
    app = App()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()
