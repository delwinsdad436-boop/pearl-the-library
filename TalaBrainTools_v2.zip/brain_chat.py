#!/usr/bin/env python3
"""
brain_chat.py — offline "chat" wrapper:
- retrieves relevant chunks from brain_index.sqlite
- can write memories to memory.sqlite
- can run simple agent actions (save pin / list memory)

Commands:
  /exit                 quit
  /probe                show DB tables/columns
  /remember <text>      save a memory note
  /pin <text>           save pinned memory
  /mem <query>          search memories
  /plan <goal>          make a simple step plan and store it
"""
import argparse, textwrap, time
from brain_common import connect, detect_brain_table, get_columns, format_hit, add_memory, search_memories, normalize_text

def retrieve(conn, table, cols, query, limit=6):
    # same heuristic as search
    text_cols = [c for c in cols if c.lower() in ("text","definition","content","body","title","term","headword","name")]
    if not text_cols:
        text_cols = [c for c in cols if c.lower() not in ("id","rowid","idx","ts","hash","sha256")]
    where = " OR ".join([f"{c} LIKE ?" for c in text_cols])
    q = f"%{query}%"
    params = [q]*len(text_cols)
    rows = conn.execute(f"SELECT rowid as rowid, * FROM {table} WHERE ({where}) LIMIT ?", (*params, limit)).fetchall()
    hits = []
    for r in rows:
        d = dict(r)
        hits.append(format_hit(d, cols))
    return hits

def answer_from_hits(question, hits):
    # lightweight, rule-based synthesis (no local LLM required)
    if not hits:
        return "I don't have a direct match in your brain yet. Try different keywords or add a memory with /remember."

    # Build a concise synthesis with citations
    bullets = []
    cites = []
    for h in hits[:5]:
        t = h["text"]
        if not t:
            continue
        # take first sentence-ish
        snippet = t.split("\n")[0]
        snippet = snippet[:180].strip()
        bullets.append(f"- {snippet}")
        if h["source"]:
            cites.append(h["source"])
    cites = [c for i,c in enumerate(cites) if c and c not in cites[:i]]

    out = []
    out.append("Here’s what your brain has on that:")
    out.extend(bullets if bullets else ["- (No text fields found in matched rows.)"])
    if cites:
        out.append("\nSources used:")
        for c in cites[:10]:
            out.append(f"- {c}")
    return "\n".join(out)

def simple_plan(goal: str):
    goal = goal.strip()
    steps = [
        f"Define success criteria for: {goal}",
        "Inventory current components + what already works",
        "Identify the single next bottleneck",
        "Execute the smallest fix that removes that bottleneck",
        "Test, then write a checkpoint note",
        "Repeat (tight loop) until stable"
    ]
    return steps

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="brain_index.sqlite")
    ap.add_argument("--limit", type=int, default=6)
    args = ap.parse_args()

    conn = connect(args.db)
    table = detect_brain_table(conn)
    cols = get_columns(conn, table)

    print("TALA Brain Chat (offline). Type your question.")
    print("Commands: /exit /probe /remember <text> /pin <text> /mem <query> /plan <goal>")
    while True:
        try:
            q = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n(exit)")
            break

        if not q:
            continue
        if q.lower() in ("/exit", "exit", "quit"):
            break
        if q.lower() == "/probe":
            print("DB:", args.db)
            print("Table:", table)
            print("Columns:", ", ".join(cols))
            continue

        if q.startswith("/remember "):
            txt = q[len("/remember "):].strip()
            mid = add_memory(kind="note", value=txt)
            print(f"Saved memory #{mid}.")
            continue

        if q.startswith("/pin "):
            txt = q[len("/pin "):].strip()
            mid = add_memory(kind="note", value=txt, pinned=True)
            print(f"Saved PINNED memory #{mid}.")
            continue

        if q.startswith("/mem "):
            mq = q[len("/mem "):].strip()
            rows = search_memories(mq, limit=10)
            if not rows:
                print("No memories found.")
                continue
            for r in rows:
                ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r["ts"]))
                pin = "PIN" if r["pinned"] else "   "
                print(f"[{pin}] #{r['id']} {ts} {r['kind']} {r.get('key') or ''}\n  {normalize_text(r['value'])}\n")
            continue

        if q.startswith("/plan "):
            goal = q[len("/plan "):].strip()
            steps = simple_plan(goal)
            plan_txt = "\n".join([f"{i+1}. {s}" for i,s in enumerate(steps)])
            add_memory(kind="plan", key=goal[:120], value=plan_txt)
            print("Plan saved to memory.sqlite:\n" + plan_txt)
            continue

        hits = retrieve(conn, table, cols, q, limit=args.limit)
        print(answer_from_hits(q, hits))

    conn.close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
