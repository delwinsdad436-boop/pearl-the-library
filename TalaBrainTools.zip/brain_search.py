#!/usr/bin/env python3
"""
brain_search.py
Offline search over brain_index.sqlite.

Usage:
  python brain_search.py "plants"
  python brain_search.py plants --top 8
  python brain_search.py plants --db brain_index.sqlite
"""

import argparse
import sqlite3
import sys
from pathlib import Path
from typing import List, Tuple, Dict, Any

DEFAULT_DB = "brain_index.sqlite"

PREFERRED_TABLES = ["brain", "cells", "records", "chunks", "entries", "docs"]

TEXT_COL_CANDIDATES = [
    "text", "content", "body", "record", "definition", "value", "data", "json", "raw", "message"
]
TITLE_COL_CANDIDATES = ["title", "name", "heading", "key", "term", "label"]
SOURCE_COL_CANDIDATES = ["source", "source_file", "file", "path", "origin", "sha256", "id"]

def connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con

def list_tables(con: sqlite3.Connection) -> List[str]:
    rows = con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
    return [r["name"] for r in rows]

def table_columns(con: sqlite3.Connection, table: str) -> List[Dict[str, Any]]:
    rows = con.execute(f"PRAGMA table_info({table})").fetchall()
    # Each row: cid, name, type, notnull, dflt_value, pk
    return [{"name": r["name"], "type": (r["type"] or "").upper()} for r in rows]

def pick_table(con: sqlite3.Connection) -> str:
    tables = list_tables(con)
    # Prefer known names
    for t in PREFERRED_TABLES:
        if t in tables:
            return t
    # Otherwise, pick the first table that's not sqlite_sequence
    for t in tables:
        if t != "sqlite_sequence":
            return t
    raise RuntimeError("No usable tables found in database.")

def pick_text_cols(cols: List[Dict[str, Any]]) -> List[str]:
    names = [c["name"] for c in cols]
    picks = []
    for cand in TEXT_COL_CANDIDATES:
        if cand in names:
            picks.append(cand)
    # If none matched, pick any column whose type looks like TEXT, or any non-numeric
    if not picks:
        for c in cols:
            t = c["type"]
            n = c["name"]
            if "TEXT" in t or "CHAR" in t or "CLOB" in t or t == "":
                picks.append(n)
        # If still none, fall back to all columns (last resort)
        if not picks:
            picks = names[:]
    # De-dup preserving order
    seen = set()
    out = []
    for x in picks:
        if x not in seen:
            out.append(x); seen.add(x)
    return out

def pick_first_present(names: List[str], candidates: List[str]) -> str:
    for c in candidates:
        if c in names:
            return c
    return ""

def row_snippet(text: str, query: str, width: int = 220) -> str:
    if not text:
        return ""
    t = " ".join(str(text).split())
    q = query.strip()
    if not q:
        return t[:width]
    idx = t.lower().find(q.lower())
    if idx < 0:
        return t[:width]
    start = max(0, idx - width // 2)
    end = min(len(t), start + width)
    snip = t[start:end]
    if start > 0:
        snip = "..." + snip
    if end < len(t):
        snip = snip + "..."
    return snip

def search(con: sqlite3.Connection, query: str, top: int = 10, table: str = "") -> List[Dict[str, Any]]:
    if not table:
        table = pick_table(con)

    cols = table_columns(con, table)
    col_names = [c["name"] for c in cols]

    text_cols = pick_text_cols(cols)
    title_col = pick_first_present(col_names, TITLE_COL_CANDIDATES)
    source_col = pick_first_present(col_names, SOURCE_COL_CANDIDATES)

    like = f"%{query}%"
    where = " OR ".join([f"{c} LIKE ?" for c in text_cols])
    params = [like] * len(text_cols)

    select_cols = []
    if title_col:
        select_cols.append(title_col)
    if source_col and source_col not in select_cols:
        select_cols.append(source_col)

    # Always select the text columns (for snippets)
    for c in text_cols:
        if c not in select_cols:
            select_cols.append(c)

    select_sql = ", ".join(select_cols)

    sql = f"SELECT {select_sql} FROM {table} WHERE {where} LIMIT ?"
    params.append(top)

    try:
        rows = con.execute(sql, params).fetchall()
    except sqlite3.OperationalError as e:
        raise RuntimeError(f"Database query failed: {e}\nTable={table}\nTextCols={text_cols}\nSQL={sql}")

    results = []
    for r in rows:
        rd = dict(r)
        # Build a primary text field for snippet
        joined = []
        for c in text_cols:
            v = rd.get(c)
            if v is not None and str(v).strip():
                joined.append(str(v))
        primary = "\n".join(joined)
        results.append({
            "title": rd.get(title_col, "") if title_col else "",
            "source": rd.get(source_col, "") if source_col else "",
            "snippet": row_snippet(primary, query),
            "raw": rd
        })
    return results

def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("query", nargs="?", help="Search query (wrap in quotes for phrases)")
    ap.add_argument("--db", default=DEFAULT_DB, help="Path to brain_index.sqlite")
    ap.add_argument("--top", type=int, default=10, help="Number of results to show")
    ap.add_argument("--table", default="", help="Override table name (optional)")
    ap.add_argument("--json", action="store_true", help="Output JSON instead of text")
    args = ap.parse_args()

    if not args.query:
        print('Usage: python brain_search.py "query"')
        sys.exit(1)

    db_path = Path(args.db)
    if not db_path.exists():
        print(f"ERROR: DB not found: {db_path.resolve()}")
        sys.exit(2)

    con = connect(str(db_path))
    try:
        results = search(con, args.query, top=args.top, table=args.table)
    except Exception as e:
        print(str(e))
        print("\nTip: run: python brain_probe.py")
        sys.exit(3)
    finally:
        con.close()

    if args.json:
        import json
        print(json.dumps({"query": args.query, "results": results}, indent=2, ensure_ascii=False))
        return

    print(f"DB: {db_path.name}")
    # Print detected table and columns quick
    try:
        con = connect(str(db_path))
        table = args.table or pick_table(con)
        cols = [c["name"] for c in table_columns(con, table)]
        con.close()
        print(f"Table: {table}")
        print(f"Columns: {', '.join(cols)}")
    except Exception:
        pass

    if not results:
        print("\nNo matches.")
        return

    for i, r in enumerate(results, 1):
        title = r["title"] or "(no title)"
        source = r["source"] or "(no source)"
        print(f"\n#{i}  {title}")
        print(f"    Source: {source}")
        print(f"    {r['snippet']}")

if __name__ == "__main__":
    main()
