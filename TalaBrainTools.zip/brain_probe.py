#!/usr/bin/env python3
"""
brain_probe.py
Debug/inspect your brain_index.sqlite quickly.

Usage:
  python brain_probe.py
  python brain_probe.py --db brain_index.sqlite
"""

import argparse
import sqlite3
from pathlib import Path

DEFAULT_DB = "brain_index.sqlite"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=DEFAULT_DB)
    args = ap.parse_args()

    db = Path(args.db)
    if not db.exists():
        print(f"ERROR: DB not found: {db.resolve()}")
        raise SystemExit(2)

    con = sqlite3.connect(str(db))
    con.row_factory = sqlite3.Row

    tables = [r["name"] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    print(f"DB: {db.resolve()}")
    print("Tables:")
    for t in tables:
        print(f"  - {t}")
        cols = con.execute(f"PRAGMA table_info({t})").fetchall()
        for c in cols:
            print(f"      {c['name']}  {c['type']}")
        # sample row count
        if t != "sqlite_sequence":
            try:
                n = con.execute(f"SELECT COUNT(*) AS n FROM {t}").fetchone()["n"]
                print(f"      rows: {n}")
            except Exception as e:
                print(f"      rows: (count failed: {e})")
    con.close()

if __name__ == "__main__":
    main()
