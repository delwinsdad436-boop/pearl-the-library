#!/usr/bin/env python3
"""
brain_gui.py
Tiny Tkinter GUI to search brain_index.sqlite.

Run:
  python brain_gui.py
"""

import sqlite3
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

DEFAULT_DB = "brain_index.sqlite"
PREFERRED_TABLES = ["brain", "cells", "records", "chunks", "entries", "docs"]
TEXT_COL_CANDIDATES = ["text", "content", "body", "record", "definition", "value", "data", "json", "raw", "message"]

def connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con

def list_tables(con):
    return [r["name"] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]

def table_columns(con, table):
    return [{"name": r["name"], "type": (r["type"] or "").upper()} for r in con.execute(f"PRAGMA table_info({table})")]

def pick_table(con):
    tables = list_tables(con)
    for t in PREFERRED_TABLES:
        if t in tables:
            return t
    for t in tables:
        if t != "sqlite_sequence":
            return t
    raise RuntimeError("No usable tables found.")

def pick_text_cols(cols):
    names = [c["name"] for c in cols]
    picks = [c for c in TEXT_COL_CANDIDATES if c in names]
    if not picks:
        for c in cols:
            t = c["type"]
            if "TEXT" in t or "CHAR" in t or "CLOB" in t or t == "":
                picks.append(c["name"])
        if not picks:
            picks = names[:]
    # unique preserve order
    out, seen = [], set()
    for x in picks:
        if x not in seen:
            out.append(x); seen.add(x)
    return out

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TALA Brain Search (offline)")
        self.geometry("980x640")

        self.db_path = Path(DEFAULT_DB)
        if not self.db_path.exists():
            messagebox.showerror("Missing DB", f"Cannot find {DEFAULT_DB} in:\n{Path.cwd()}")
            self.destroy()
            return

        self.con = connect(str(self.db_path))
        self.table = pick_table(self.con)
        self.text_cols = pick_text_cols(table_columns(self.con, self.table))

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)

        ttk.Label(top, text="Query:").pack(side="left")
        self.q = tk.StringVar()
        e = ttk.Entry(top, textvariable=self.q, width=60)
        e.pack(side="left", padx=8)
        e.bind("<Return>", lambda _e: self.do_search())

        ttk.Button(top, text="Search", command=self.do_search).pack(side="left")
        ttk.Label(top, text=f"DB: {DEFAULT_DB}  |  Table: {self.table}").pack(side="left", padx=12)

        self.results = tk.Text(self, wrap="word")
        self.results.pack(fill="both", expand=True, padx=10, pady=(0,10))

        self.status = ttk.Label(self, text="Ready.")
        self.status.pack(fill="x", padx=10, pady=(0,10))

    def do_search(self):
        query = self.q.get().strip()
        if not query:
            return
        like = f"%{query}%"
        where = " OR ".join([f"{c} LIKE ?" for c in self.text_cols])
        params = [like] * len(self.text_cols)

        sql = f"SELECT * FROM {self.table} WHERE {where} LIMIT 20"
        try:
            rows = self.con.execute(sql, params).fetchall()
        except Exception as e:
            messagebox.showerror("DB error", str(e))
            return

        self.results.delete("1.0", "end")
        self.results.insert("end", f"Query: {query}\nMatches: {len(rows)}\n\n")
        for i, r in enumerate(rows, 1):
            rd = dict(r)
            chunks = []
            for c in self.text_cols:
                v = rd.get(c)
                if v is not None and str(v).strip():
                    chunks.append(str(v))
            text = " ".join("\n".join(chunks).split())
            if len(text) > 700:
                text = text[:700] + "..."
            self.results.insert("end", f"#{i}\n{text}\n\n---\n\n")

        self.status.configure(text=f"Done. {len(rows)} matches.")

    def destroy(self):
        try:
            if hasattr(self, "con") and self.con:
                self.con.close()
        except Exception:
            pass
        super().destroy()

if __name__ == "__main__":
    App().mainloop()
