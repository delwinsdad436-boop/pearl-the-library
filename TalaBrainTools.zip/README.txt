TalaBrainTools (offline)
======================

Put these files into your TalaRipper folder (same folder as brain_index.sqlite).

FILES
- brain_probe.py   : prints tables/columns/row counts (debug)
- brain_search.py  : command line search tool (fast)
- brain_chat.py    : interactive chat wrapper (retrieval-based, no cloud)
- brain_gui.py     : simple Tkinter GUI (optional)

QUICK START (Windows CMD)
1) Go to your folder:
   cd /d "C:\Users\delwi\TalaRipper"

2) Probe the DB (shows table names + columns):
   python brain_probe.py

3) Search:
   python brain_search.py "plants"
   python brain_search.py "garlic" --top 15

4) Chat:
   python brain_chat.py
   (type questions, /exit quits)

5) GUI (optional):
   python brain_gui.py

NOTES
- This is fully offline.
- Search uses SQL LIKE across detected text columns.
- If your database/table schema changes, these tools auto-detect the main table and text columns.
