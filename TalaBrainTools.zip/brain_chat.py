#!/usr/bin/env python3
"""
brain_chat.py
Offline chat wrapper over brain_search.py.
This is NOT a large language model. It does retrieval + clean stitched responses.

Usage:
  python brain_chat.py
  python brain_chat.py --db brain_index.sqlite
"""

import argparse
from pathlib import Path
from typing import List, Dict

import sqlite3

DEFAULT_DB = "brain_index.sqlite"

PREFERRED_TABLES = ["brain", "cells", "records", "chunks", "entries", "docs"]
TEXT_COL_CANDIDATES = ["text", "content", "body", "record", "definition", "value", "data", "json", "raw", "message"]

def connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    return con

def list_tables(con: sqlite3.Connection) -> List[str]:
    return [r["name"] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]

def table_columns(con: sqlite3.Connection, table: str):
    return [{"name": r["name"], "type": (r["type"] or "").upper()} for r in con.execute(f"PRAGMA table_info({table})")]

def pick_table(con: sqlite3.Connection) -> str:
    tables = list_tables(con)
    for t in PREFERRED_TABLES:
        if t in tables:
            return t
    for t in tables:
        if t != "sqlite_sequence":
            return t
    raise RuntimeError("No usable tables found in database.")

def pick_text_cols(cols):
    names = [c["name"] for c in cols]
    picks = [c for c in TEXT_COL_CANDIDATES if c in names]
    if not picks:
        for c in cols:
            t = c["type"]
            if "TEXT" in t or "CHAR" in t or "CLOB" in t or t == "":
                picks.append(c["name"])
        if not picks:
            picks = names[:]
    # unique preserve order
    out, seen = [], set()
    for x in picks:
        if x not in seen:
            out.append(x); seen.add(x)
    return out

def search(con: sqlite3.Connection, query: str, top: int = 6, table: str = "") -> List[Dict]:
    if not table:
        table = pick_table(con)
    cols = table_columns(con, table)
    text_cols = pick_text_cols(cols)

    like = f"%{query}%"
    where = " OR ".join([f"{c} LIKE ?" for c in text_cols])
    params = [like] * len(text_cols)
    sql = f"SELECT * FROM {table} WHERE {where} LIMIT ?"
    params.append(top)
    rows = con.execute(sql, params).fetchall()
    out = []
    for r in rows:
        rd = dict(r)
        chunks = []
        for c in text_cols:
            v = rd.get(c)
            if v is not None and str(v).strip():
                chunks.append(str(v))
        out.append({"raw": rd, "text": "\n".join(chunks)})
    return out

def simple_answer(query: str, hits: List[Dict]) -> str:
    if not hits:
        return "No matches found in your brain yet."
    # Extractive stitch: top 3 snippets, lightly cleaned
    parts = []
    for h in hits[:3]:
        t = " ".join(h["text"].split())
        if len(t) > 500:
            t = t[:500] + "..."
        parts.append(t)
    answer = (
        f"Query: {query}\n\n"
        f"Top matches stitched (extractive):\n"
        + "\n\n---\n\n".join(parts)
    )
    return answer

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--top", type=int, default=6)
    ap.add_argument("--table", default="")
    args = ap.parse_args()

    db = Path(args.db)
    if not db.exists():
        print(f"ERROR: DB not found: {db.resolve()}")
        raise SystemExit(2)

    print("TALA Brain Chat (offline) — type your question.  /exit to quit.  /probe to show tables.\n")

    con = connect(str(db))
    try:
        while True:
            q = input("> ").strip()
            if not q:
                continue
            if q.lower() in ("/exit", "exit", "quit", "/q"):
                break
            if q.lower() in ("/probe", "/tables"):
                tables = list_tables(con)
                print("Tables:", ", ".join(tables))
                continue

            try:
                hits = search(con, q, top=args.top, table=args.table)
            except Exception as e:
                print(f"DB error: {e}")
                print('Tip: run "python brain_probe.py"')
                continue

            print()
            print(simple_answer(q, hits))
            print()
    finally:
        con.close()

if __name__ == "__main__":
    main()
