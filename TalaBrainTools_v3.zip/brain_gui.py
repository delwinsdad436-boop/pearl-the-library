#!/usr/bin/env python3
"""brain_gui.py

Simple offline GUI search for brain_index.sqlite.
- Type a query
- Click Search
- Click a result to preview

Requires: built-in tkinter (usually included with Windows Python).
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

DB_DEFAULT = "brain_index.sqlite"
TABLE_DEFAULT = "brain"


def connect_db(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TALA Brain GUI (offline)")
        self.geometry("1100x700")

        self.db = None
        self.table = TABLE_DEFAULT

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)

        ttk.Label(top, text="Query:").pack(side="left")
        self.q = tk.StringVar()
        ttk.Entry(top, textvariable=self.q, width=60).pack(side="left", padx=8)

        self.limit = tk.IntVar(value=25)
        ttk.Label(top, text="Limit:").pack(side="left")
        ttk.Entry(top, textvariable=self.limit, width=6).pack(side="left", padx=6)

        ttk.Button(top, text="Search", command=self.search).pack(side="left", padx=8)

        mid = ttk.Panedwindow(self, orient=tk.HORIZONTAL)
        mid.pack(fill="both", expand=True, padx=10, pady=10)

        left = ttk.Frame(mid)
        right = ttk.Frame(mid)
        mid.add(left, weight=1)
        mid.add(right, weight=2)

        self.listbox = tk.Listbox(left)
        self.listbox.pack(fill="both", expand=True)
        self.listbox.bind("<<ListboxSelect>>", self.on_select)

        self.preview = tk.Text(right, wrap="word")
        self.preview.pack(fill="both", expand=True)

        self._rows = []
        self._open_db()

    def _open_db(self):
        db_path = Path(DB_DEFAULT)
        if not db_path.exists():
            messagebox.showerror("Missing DB", f"{DB_DEFAULT} not found in this folder.")
            return
        self.db = connect_db(db_path)

        # Prefer the expected table name
        tables = [r[0] for r in self.db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()]
        if self.table not in tables and tables:
            self.table = tables[0]

    def search(self):
        self.preview.delete("1.0", tk.END)
        self.listbox.delete(0, tk.END)
        self._rows = []

        if not self.db:
            return

        q = (self.q.get() or "").strip()
        if not q:
            return

        lim = self.limit.get() if self.limit.get() > 0 else 25

        # Basic LIKE search (works everywhere)
        sql = f"""
            SELECT id, record_index, source_file, title, content
            FROM {self.table}
            WHERE content LIKE ? OR IFNULL(title, '') LIKE ?
            LIMIT ?
        """
        rows = self.db.execute(sql, (f"%{q}%", f"%{q}%", lim)).fetchall()

        self._rows = rows
        for r in rows:
            title = (r["title"] or "(no title)").strip()
            src = (r["source_file"] or "?")
            idx = r["record_index"]
            self.listbox.insert(tk.END, f"#{idx} | {src} | {title}"[:180])

        if not rows:
            self.listbox.insert(tk.END, "(no matches)")

    def on_select(self, _evt=None):
        if not self._rows:
            return
        sel = self.listbox.curselection()
        if not sel:
            return
        i = sel[0]
        if i >= len(self._rows):
            return

        r = self._rows[i]
        self.preview.delete("1.0", tk.END)
        self.preview.insert(tk.END, f"Record #{r['record_index']}\n")
        self.preview.insert(tk.END, f"Source: {r['source_file']}\n")
        self.preview.insert(tk.END, f"Title: {r['title'] or '(no title)'}\n")
        self.preview.insert(tk.END, "\n")
        self.preview.insert(tk.END, r["content"] or "")


if __name__ == "__main__":
    App().mainloop()
