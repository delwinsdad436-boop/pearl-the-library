#!/usr/bin/env python3
"""brain_search.py

Offline search over TalaRipper's assembled SQLite brain.

Default DB: brain_index.sqlite (created by assemble_brain_v2.py)
Expected table: brain

Examples:
  python brain_search.py plants
  python brain_search.py --limit 20 "quantum field"
  python brain_search.py --probe
  python brain_search.py --db brain_index.sqlite plants
"""

from __future__ import annotations

import argparse
import re
import sqlite3
import sys
from pathlib import Path
from typing import Iterable, Tuple


def _connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def _tables(conn: sqlite3.Connection) -> list[str]:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()
    return [r[0] for r in rows]


def _has_table(conn: sqlite3.Connection, name: str) -> bool:
    return name in set(_tables(conn))


def _escape_like(s: str) -> str:
    # Escape SQL LIKE wildcards
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def search(conn: sqlite3.Connection, query: str, limit: int = 10) -> Iterable[sqlite3.Row]:
    # Table schema (from your screenshot):
    # brain(id INTEGER PRIMARY KEY AUTOINCREMENT,
    #       record_index INTEGER,
    #       source_file TEXT,
    #       content TEXT)
    q = query.strip()
    if not q:
        return []

    # Tokenize into words; require all tokens in content (AND)
    tokens = [t for t in re.split(r"\s+", q) if t]
    where = []
    params = []
    for t in tokens:
        where.append("content LIKE ? ESCAPE '\\'")
        params.append(f"%{_escape_like(t)}%")

    sql = (
        "SELECT id, record_index, source_file, content "
        "FROM brain "
        f"WHERE {' AND '.join(where)} "
        "ORDER BY record_index ASC "
        "LIMIT ?"
    )
    params.append(int(limit))
    return conn.execute(sql, params)


def probe(db_path: Path) -> int:
    if not db_path.exists():
        raise FileNotFoundError(f"DB not found: {db_path}")
    conn = _connect(db_path)
    try:
        tbls = _tables(conn)
        print("DB:", db_path)
        print("Tables:", tbls)
        if "brain" in tbls:
            cnt = conn.execute("SELECT COUNT(*) FROM brain").fetchone()[0]
            print("brain rowcount:", cnt)
            return int(cnt)
        return 0
    finally:
        conn.close()


def main(argv: list[str]) -> int:
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--db", default="brain_index.sqlite", help="Path to brain_index.sqlite")
    p.add_argument("--limit", type=int, default=10, help="Max results")
    p.add_argument("--probe", action="store_true", help="Show DB tables and rowcount")
    p.add_argument("--help", action="store_true", help="Show help")
    p.add_argument("query", nargs="*", help="Search query")
    args = p.parse_args(argv)

    if args.help:
        print(__doc__)
        return 0

    db_path = Path(args.db)

    if args.probe:
        try:
            probe(db_path)
            return 0
        except Exception as e:
            print("Probe error:", e)
            return 2

    q = " ".join(args.query).strip()
    if not q:
        print("Usage: python brain_search.py [--db brain_index.sqlite] [--limit 10] <query>")
        print("Example: python brain_search.py plants")
        return 2

    if not db_path.exists():
        print(f"DB not found: {db_path}")
        print("Run assembler first to create brain_index.sqlite.")
        return 2

    conn = _connect(db_path)
    try:
        if not _has_table(conn, "brain"):
            print("Database error: expected table 'brain' was not found.")
            print("Tables present:", _tables(conn))
            return 3

        rows = list(search(conn, q, limit=args.limit))
        if not rows:
            print("No matches found in your brain yet.")
            return 0

        for i, r in enumerate(rows, start=1):
            content = (r["content"] or "").replace("\r", " ")
            snippet = content[:350].replace("\n", " ")
            print(f"#{i}  id={r['id']}  record_index={r['record_index']}  source={r['source_file']}")
            print("   ", snippet + ("..." if len(content) > 350 else ""))
            print()
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
