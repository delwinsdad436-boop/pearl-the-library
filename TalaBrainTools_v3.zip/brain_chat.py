#!/usr/bin/env python3
"""brain_chat.py

Tiny offline "chat" wrapper around brain_index.sqlite.

Commands:
  /exit  -> quit
  /probe -> show tables + row count

Normal input: any question/keyword(s) you want to search.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

DB_DEFAULT = "brain_index.sqlite"


def _connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def _tables(conn: sqlite3.Connection) -> list[str]:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()
    return [r[0] for r in rows]


def _count(conn: sqlite3.Connection, table: str) -> int:
    try:
        return int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
    except Exception:
        return -1


def search(conn: sqlite3.Connection, query: str, limit: int = 10) -> list[sqlite3.Row]:
    q = query.strip()
    if not q:
        return []

    # TalaRipper schema (assemble_brain_v2):
    # brain(id, record_index, source_file, title, content)
    # We'll match against title+content.
    like = f"%{q}%"
    sql = (
        "SELECT id, record_index, source_file, title, content "
        "FROM brain "
        "WHERE (title LIKE ? OR content LIKE ?) "
        "ORDER BY id ASC "
        "LIMIT ?"
    )
    return conn.execute(sql, (like, like, int(limit))).fetchall()


def _print_hits(rows: list[sqlite3.Row]) -> None:
    if not rows:
        print("No matches found in your brain yet.")
        return

    for i, r in enumerate(rows, 1):
        title = (r["title"] or "(no title)").strip()
        src = (r["source_file"] or "?").strip()
        content = (r["content"] or "").strip().replace("\n", " ")
        snippet = (content[:260] + "...") if len(content) > 260 else content
        print(f"\n#{i} {title}")
        print(f"  Source: {src} (record_index={r['record_index']})")
        print(f"  {snippet}")


def main() -> int:
    db_path = Path(DB_DEFAULT)
    if not db_path.exists():
        print(f"DB not found: {db_path}. Run: python assemble_brain_v2.py --nano-dir nano_out --rebuild")
        return 2

    conn = _connect(db_path)
    try:
        print("TALA Brain Chat (offline) — type your question.  /exit to quit.  /probe to show tables.")
        while True:
            try:
                line = input("> ")
            except EOFError:
                print()
                break
            except KeyboardInterrupt:
                print("\n(CTRL+C) — type /exit to quit, or keep going.")
                continue

            msg = line.strip()
            if not msg:
                continue
            if msg.lower() in {"/exit", "exit", "quit", "q"}:
                break
            if msg.lower() == "/probe":
                ts = _tables(conn)
                print("Tables:", ", ".join(ts) if ts else "(none)")
                if "brain" in ts:
                    print("brain rows:", _count(conn, "brain"))
                continue

            rows = search(conn, msg, limit=10)
            _print_hits(rows)

        return 0
    finally:
        try:
            conn.close()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
