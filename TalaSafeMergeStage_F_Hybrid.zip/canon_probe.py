#!/usr/bin/env python3
import argparse, sqlite3, json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--sample", type=int, default=10)
    args = ap.parse_args()

    conn = sqlite3.connect(args.db)
    conn.row_factory = sqlite3.Row

    counts = {}
    for name in ["canon_map","canon_override","canon_decision_log"]:
        counts[name] = conn.execute(f"SELECT COUNT(*) AS n FROM {name}").fetchone()["n"]

    sample = [dict(r) for r in conn.execute(
        '''
        SELECT b.id,
               COALESCE(co.canon_id, cm.canon_id, b.id) AS effective_canon_id,
               CASE WHEN co.canon_id IS NOT NULL THEN 'override'
                    WHEN cm.canon_id IS NOT NULL THEN 'auto'
                    ELSE 'self' END AS source
        FROM brain b
        LEFT JOIN canon_override co ON co.alias_id=b.id
        LEFT JOIN canon_map cm ON cm.alias_id=b.id
        WHERE co.alias_id IS NOT NULL OR cm.alias_id IS NOT NULL
        ORDER BY RANDOM()
        LIMIT ?
        ''',
        (args.sample,)
    ).fetchall()]

    conn.close()

    print("CANON PROBE")
    print(json.dumps({"counts": counts, "sample_effective": sample}, indent=2))

if __name__ == "__main__":
    main()
