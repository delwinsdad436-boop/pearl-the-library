#!/usr/bin/env python3
import argparse, sqlite3, csv, os, shutil, datetime, json

def backup_db(db_path: str, out_dir: str = "backups") -> str:
    os.makedirs(out_dir, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    base = os.path.basename(db_path)
    out = os.path.join(out_dir, f"{base}.bak_{ts}")
    shutil.copy2(db_path, out)
    return out

def log(conn, action, alias_id=None, canon_id=None, score=None, meta=None):
    meta_json = json.dumps(meta or {}, ensure_ascii=False)
    conn.execute(
        "INSERT INTO canon_decision_log(action, alias_id, canon_id, score, meta_json, created_at) VALUES (?,?,?,?,?,datetime('now'))",
        (action, alias_id, canon_id, score, meta_json),
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--csv", required=True, help="CSV with columns: alias_id,canon_id (header ok)")
    ap.add_argument("--note", default="human_override")
    args = ap.parse_args()

    backup_path = backup_db(args.db)
    print(f"[BACKUP] {backup_path}")

    conn = sqlite3.connect(args.db)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")

    applied = 0
    with open(args.csv, "r", encoding="utf-8-sig", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            if not row:
                continue
            alias_id = int(row.get("alias_id") or row.get("alias") or row.get("a_id"))
            canon_id = int(row.get("canon_id") or row.get("canon") or row.get("b_id"))
            note = (row.get("note") or "").strip() or args.note

            conn.execute(
                "INSERT OR REPLACE INTO canon_override(alias_id, canon_id, note, created_at) VALUES (?,?,?,datetime('now'))",
                (alias_id, canon_id, note),
            )
            log(conn, "apply_override", alias_id=alias_id, canon_id=canon_id, meta={"note": note})
            applied += 1

    conn.commit()
    conn.close()

    print("DONE")
    print(json.dumps({"applied_overrides": applied, "backup": backup_path}, indent=2))

if __name__ == "__main__":
    main()
