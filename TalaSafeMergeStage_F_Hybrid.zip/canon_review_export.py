#!/usr/bin/env python3
import argparse, sqlite3, csv, json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--out", required=True, help="review.csv or review.jsonl")
    ap.add_argument("--min-score", type=float, default=0.0)
    ap.add_argument("--max-score", type=float, default=1.0)
    ap.add_argument("--limit", type=int, default=1000)
    args = ap.parse_args()

    conn = sqlite3.connect(args.db)
    conn.row_factory = sqlite3.Row

    rows = conn.execute(
        '''
        SELECT alias_id, canon_id, score, reason, created_at
        FROM canon_map
        WHERE score BETWEEN ? AND ?
        ORDER BY score DESC
        LIMIT ?
        ''',
        (args.min_score, args.max_score, args.limit),
    ).fetchall()
    conn.close()

    if args.out.lower().endswith(".jsonl"):
        with open(args.out, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(dict(r), ensure_ascii=False) + "\n")
        print(f"WROTE {len(rows)} rows to {args.out}")
        return

    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["alias_id","canon_id","score","reason","created_at","note"])
        for r in rows:
            w.writerow([r["alias_id"], r["canon_id"], r["score"], r["reason"], r["created_at"], ""])
    print(f"WROTE {len(rows)} rows to {args.out}")

if __name__ == "__main__":
    main()
