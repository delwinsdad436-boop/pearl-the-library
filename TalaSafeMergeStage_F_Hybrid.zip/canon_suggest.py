#!/usr/bin/env python3
import argparse, sqlite3, json, os, shutil, datetime

def backup_db(db_path: str, out_dir: str = "backups") -> str:
    os.makedirs(out_dir, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    base = os.path.basename(db_path)
    out = os.path.join(out_dir, f"{base}.bak_{ts}")
    shutil.copy2(db_path, out)
    return out

def log(conn, action, alias_id=None, canon_id=None, score=None, meta=None):
    meta_json = json.dumps(meta or {}, ensure_ascii=False)
    conn.execute(
        "INSERT INTO canon_decision_log(action, alias_id, canon_id, score, meta_json, created_at) VALUES (?,?,?,?,?,datetime('now'))",
        (action, alias_id, canon_id, score, meta_json),
    )

def ensure_layer(conn):
    cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('canon_map','canon_override','canon_decision_log')")
    names = {r[0] for r in cur.fetchall()}
    missing = {'canon_map','canon_override','canon_decision_log'} - names
    if missing:
        raise SystemExit(f"Missing canonical layer tables: {sorted(missing)}. Run: python canon_build.py --db your.sqlite --backup")

def parse_plan_line(line: str):
    obj = json.loads(line)
    a = int(obj["a_id"]); b = int(obj["b_id"])
    s = float(obj.get("score", 0.0))
    return a, b, s, obj

def choose_canon(a_id, b_id, a_len=None, b_len=None):
    if a_len is not None and b_len is not None:
        if float(b_len) > float(a_len):
            return b_id, a_id
        return a_id, b_id
    return (min(a_id,b_id), max(a_id,b_id))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--plan", required=True, help="merge_plan.jsonl (JSON Lines)")
    ap.add_argument("--threshold", type=float, default=0.99)
    ap.add_argument("--apply", action="store_true", help="Write suggestions into canon_map (non-destructive)")
    ap.add_argument("--dry-run", action="store_true", help="No writes, just stats")
    ap.add_argument("--limit", type=int, default=0, help="0 = no limit")
    args = ap.parse_args()

    if args.apply and args.dry_run:
        raise SystemExit("Choose either --apply or --dry-run, not both.")

    conn = sqlite3.connect(args.db)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    ensure_layer(conn)

    backup_path = None
    if args.apply:
        backup_path = backup_db(args.db)
        print(f"[BACKUP] {backup_path}")

    total = kept = skipped_low = skipped_has_override = skipped_already_mapped = 0
    applied = 0

    with open(args.plan, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total += 1
            a, b, s, raw = parse_plan_line(line)
            if s < args.threshold:
                skipped_low += 1
                continue

            # If either id has a human override, don't auto-map it.
            cur = conn.execute("SELECT 1 FROM canon_override WHERE alias_id IN (?,?) LIMIT 1", (a,b)).fetchone()
            if cur:
                skipped_has_override += 1
                continue

            canon_id, alias_id = choose_canon(a, b, raw.get("a_len"), raw.get("b_len"))

            # idempotent: skip if already mapped
            cur2 = conn.execute("SELECT canon_id FROM canon_map WHERE alias_id=?", (alias_id,)).fetchone()
            if cur2:
                skipped_already_mapped += 1
                continue

            kept += 1
            if args.dry_run:
                if args.limit and kept >= args.limit:
                    break
                continue

            meta = {"plan": os.path.basename(args.plan)}
            log(conn, "suggest", alias_id=alias_id, canon_id=canon_id, score=s, meta=meta)

            if args.apply:
                conn.execute(
                    "INSERT OR REPLACE INTO canon_map(alias_id, canon_id, score, reason, created_at) VALUES (?,?,?,?,datetime('now'))",
                    (alias_id, canon_id, s, "merge_plan"),
                )
                log(conn, "apply_auto", alias_id=alias_id, canon_id=canon_id, score=s, meta=meta)
                applied += 1

            if args.limit and kept >= args.limit:
                break

    if not args.dry_run:
        conn.commit()
    conn.close()

    print("DONE")
    print(json.dumps({
        "threshold": args.threshold,
        "total_plan_rows": total,
        "above_threshold_new": kept,
        "skipped_below_threshold": skipped_low,
        "skipped_has_override": skipped_has_override,
        "skipped_already_mapped": skipped_already_mapped,
        "applied_to_canon_map": applied,
        "backup": backup_path
    }, indent=2))

if __name__ == "__main__":
    main()
