Tala Safe Merge — Stage F (Hybrid Canonical Routing)
====================================================

You chose **C = Hybrid**: auto-canonical routing with a human override lane.

This stage does NOT delete anything.
It builds a canonical "map layer" on top of your existing `brain_index.sqlite` so:
- Search/chat routes through canonical nodes automatically
- You can review/override any auto decisions
- All changes are reversible (backup + log)

Files
-----
1) canon_build.py
   - Creates canonical tables/views if missing:
     * canon_map (alias_id -> canon_id)
     * canon_override (alias_id -> canon_id, set by human)
     * canon_decision_log (every decision)
   - Creates a view `brain_canon_view` with effective_canon_id

2) canon_suggest.py
   - Reads your existing merge_plan.jsonl (JSON Lines)
   - Generates canonical suggestions and (optionally) writes them to canon_map
   - Hybrid behavior:
       * suggestions go to canon_map
       * human overrides go to canon_override and always win

3) canon_review_export.py
   - Exports candidates for review (CSV/JSONL)

4) canon_apply_override.py
   - Apply human decisions from a small CSV (alias_id, canon_id)

5) canon_probe.py
   - Quick check: counts + sample effective mappings

Typical Workflow (Hybrid)
------------------------
STEP 1) Build canonical layer (safe, idempotent)
    python canon_build.py --db brain_index.sqlite --backup

STEP 2) Generate suggestions from merge_plan.jsonl
    python canon_suggest.py --db brain_index.sqlite --plan merge_plan.jsonl --threshold 0.99 --apply

(Preview only:)
    python canon_suggest.py --db brain_index.sqlite --plan merge_plan.jsonl --threshold 0.99 --dry-run

STEP 3) Export a review sheet
    python canon_review_export.py --db brain_index.sqlite --out review.csv --min-score 0.990 --max-score 0.999 --limit 500

Edit review.csv:
- Keep ONLY the rows you want to override
- Set alias_id -> canon_id exactly how you want

STEP 4) Apply overrides
    python canon_apply_override.py --db brain_index.sqlite --csv overrides.csv

STEP 5) Verify
    python canon_probe.py --db brain_index.sqlite --sample 20

Notes
-----
- alias_id = the record you consider duplicate.
- canon_id = the record you want as canonical.
- canon_override ALWAYS wins over canon_map.

Rollback
--------
Every apply step creates a timestamped DB backup in ./backups/
Every change is logged in canon_decision_log.
