#!/usr/bin/env python3
import argparse, sqlite3, os, json, shutil, datetime

DDL = [
    '''
    CREATE TABLE IF NOT EXISTS canon_map (
        alias_id INTEGER PRIMARY KEY,
        canon_id INTEGER NOT NULL,
        score REAL,
        reason TEXT,
        created_at TEXT NOT NULL
    );
    ''',
    '''
    CREATE TABLE IF NOT EXISTS canon_override (
        alias_id INTEGER PRIMARY KEY,
        canon_id INTEGER NOT NULL,
        note TEXT,
        created_at TEXT NOT NULL
    );
    ''',
    '''
    CREATE TABLE IF NOT EXISTS canon_decision_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        alias_id INTEGER,
        canon_id INTEGER,
        score REAL,
        meta_json TEXT,
        created_at TEXT NOT NULL
    );
    ''',
    'CREATE INDEX IF NOT EXISTS idx_canon_map_canon_id ON canon_map(canon_id);',
    'CREATE INDEX IF NOT EXISTS idx_canon_log_action ON canon_decision_log(action);',
]

VIEW_SQL = '''
CREATE VIEW IF NOT EXISTS brain_canon_view AS
SELECT
    b.id AS id,
    b.record_index AS record_index,
    b.source_file AS source_file,
    b.content AS content,
    COALESCE(co.canon_id, cm.canon_id, b.id) AS effective_canon_id,
    CASE
      WHEN co.canon_id IS NOT NULL THEN 'override'
      WHEN cm.canon_id IS NOT NULL THEN 'auto'
      ELSE 'self'
    END AS canon_source
FROM brain b
LEFT JOIN canon_override co ON co.alias_id = b.id
LEFT JOIN canon_map cm ON cm.alias_id = b.id;
'''

def backup_db(db_path: str, out_dir: str = "backups") -> str:
    os.makedirs(out_dir, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    base = os.path.basename(db_path)
    out = os.path.join(out_dir, f"{base}.bak_{ts}")
    shutil.copy2(db_path, out)
    return out

def log(conn, action, alias_id=None, canon_id=None, score=None, meta=None):
    meta_json = json.dumps(meta or {}, ensure_ascii=False)
    conn.execute(
        "INSERT INTO canon_decision_log(action, alias_id, canon_id, score, meta_json, created_at) VALUES (?,?,?,?,?,datetime('now'))",
        (action, alias_id, canon_id, score, meta_json),
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True, help="Path to brain_index.sqlite")
    ap.add_argument("--backup", action="store_true", help="Create a DB backup before building tables/views")
    args = ap.parse_args()

    if args.backup:
        b = backup_db(args.db)
        print(f"[BACKUP] {b}")

    conn = sqlite3.connect(args.db)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        for sql in DDL:
            conn.executescript(sql)
        conn.executescript(VIEW_SQL)
        log(conn, "build_layer", meta={"db": args.db})
        conn.commit()
        print("OK: canonical layer ready (canon_map, canon_override, canon_decision_log, brain_canon_view).")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
